#encoding: UTF-8
# Autor: Luis Martín Barbosa Galindo, A01337485
# Descripcion: Calcula la distancia y el tiempo desde la velocidad

# A partir de aqui escribe tu programa
V = int( input("Dime a que velocidad ibas "))
d1 = V * 6
d2 = V *10
t = 500 / V

print ("En 6 horas recorreras",d1,"km, en 10 horas recorreras",d2,"km, y si recorres 500 km tardaras",t,"horas.")

# Solucion
