#encoding: UTF-8
# Autor: Luis Martín Barbosa Galindo, A01337485 
# Descripcion: Dame las coordenadas de X y Y

from math import atan2, pi

# A partir de aqui escribe tu programa

X = int( input("Dame la coordenada en x"))
Y = int( input("Dame la coordenada en y"))
arcotan = atan2(Y , X)
ngulo = arcotan * (180/pi)
r = ((X**2)+(Y**2))**(.5)

print ("La magnitud del vector r es",r,"y su ángulo de inclinacion es",ngulo,"°.")


