#encoding: UTF-8
# Autor: Luis Martín Barbosa Galindo, A01337485
# Descripcion: Cuanto costo tu comida y te calcula la propina y el iva

# A partir de aqui escribe tu programa

costo_C = int( input("Cuanto costo la comida?") )
iva = costo_C * .16
prop = costo_C * .15
tot_c = costo_C + iva + prop

print ("Pagaste en total: $",tot_c,"con un iva de $",iva,"y con una propina de $",prop,".")