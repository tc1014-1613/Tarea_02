#encoding: UTF-8
# Autor: Luis Martín Barbosa Galindo A01337485
# Descripcion: Imprime tu nombre y matricula

print("Mi nombre es Luis Martín Barbosa Galindo")
print("Mi matrícula es A01337485")
print("Mi carrera es Ingenir¿ería en Sistemas Digitales y Robótica. (ISDR)")
print("Me gusta hacer la tarea de programacion, miobligacion es estudiar y me encanta jugar videojuegos")