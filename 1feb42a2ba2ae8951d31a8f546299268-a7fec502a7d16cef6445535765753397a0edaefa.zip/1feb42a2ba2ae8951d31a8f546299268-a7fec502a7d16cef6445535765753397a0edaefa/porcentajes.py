#encoding: UTF-8
# Autor: Luis Martín Barbosa Galindo A01337485
# Descripcion: Porcentaje de mujeres y hombres.

# A partir de aqui escribe tu programa
h = int( input("Cuantos hombres hay?") )
m = int( input("Cuantas mujeres hay?") )
tot = h + m
P_h = (100 * h) / tot
P_m = (100 * m) / tot

print ("Hay",tot,"alumnos y de esos alumnos el",P_h,"% son hombres y el otro",P_m,"% son de mujeres.")