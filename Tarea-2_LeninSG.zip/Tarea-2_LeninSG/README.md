# Tarea_02
Tarea 2. Algoritmos

Consulta el documento anexo Tarea_02_AP.docx para ver los detalles.