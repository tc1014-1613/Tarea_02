#encoding: UTF-8

# Autor: Lenin Silva Gutiérrez, A01373214
# Calcula la distancia y el tiempo de recorrido para una velocidad dada por el usuario.

# Pedir velocidad del auto en km/h

vel=int(input("Velocidad en km/h"))

#Calcular

dist_1=vel*6
dist_2=vel*10
temp=500/vel

#Finalizar

print ("En 6 horas se recorren ", dist_1, "km")
print ("En 10 horas se recorren ", dist_2, "km")
print ("Se recorren 500km en ", temp, " horas")