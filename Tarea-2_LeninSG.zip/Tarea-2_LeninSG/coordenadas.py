#encoding: UTF-8
# Autor: Lenin Silva Gutirrez, A01373214
# Convierte a coordenadas polares

from math import atan2, pi

#Pedir x, y

x=int(input("X"))
y=int(input("Y"))

#Calcular r, theta (en grados)
r=(x**2+y**2)**.5
theta=atan2(y,x)*(180/pi)

#Imprimir valores
print ("Las coordenadas polares son: (", r, ", ", theta, "°)")
