#encoding: UTF-8
# Autor: Lenin Silva Gutirrez, A01373214 
# Calcula el total a pagar de una cuenta

#Pedir costo de la comida
costo=int(input("Costo de la comida"))

#Calcular propina, IVA y total
propina=costo*0.15
iva=costo*0.16
total=costo+propina+iva

#Imprimir resultados
print ("Subtotal: ", costo)
print ("Propina: ", propina)
print ("IVA: ", iva)
print ("Total: ", total)
