#encoding: UTF-8

# Autor: Lenin Silva Gutiérrez, A01373214
# Información sobre mí.

# Imprime la información

print ("""Lenin Silva Gutierrez
A01373214
ISDR
Llevo seis semestres practicando el arte marcial Lima Lama.
Me gusta mucho jugar con amigos, ya sea deportes, videojuegos, o juegos de mesa.
Planeo viajar a distintas partes del mundo cuando acabe la universidad.""")

