#encoding: UTF-8
# Autor: Lenin Silva Gutirrez, A01373214 
# Calcula alumnos inscritos y porcentajes de mujeres y hombres

# Pedir número de mujeres y hombres
m=int(input("Mujeres"))
h=int(input("Hombres"))

# Calcular 
alum=m+h
m_por=(m/alum)*100
h_por=(h/alum)*100

#Imprimir
print ("Hay ", alum, " alumnos")
print ("Mujeres: ", m_por, "%")
print ("Hombres: ", h_por, "%")